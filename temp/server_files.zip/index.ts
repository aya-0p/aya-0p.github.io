import express from "express";
import path from "node:path";
import multer from "multer";
import bodyParser from "body-parser";
import compression from "compression";
import http from "node:http";
import socket_io from "socket.io";
import fs from "node:fs";

const app = express();
const h = http.createServer(app).listen(80, () => {
  console.log(`http://localhost/ listening on port ${80}!`);
});
app.use(
  compression({
    level: 9,
    memLevel: 9,
  })
);

app.use(bodyParser.urlencoded({ extended: true, limit: "1000gb" }));
app.use(bodyParser.json({ limit: "1000gb" }));
h.timeout = 60 * 60 * 1000;
h.keepAliveTimeout = 60 * 60 * 1000;
h.requestTimeout = 60 * 60 * 1000;

app.post(
  "/",
  multer({
    storage: multer.diskStorage({
      destination: function (req, file, cb) {
        cb(null, __dirname);
      },
      filename: function (req, file, cb) {
        cb(
          null,
          `${new Date().toISOString().replace(/:/g, ".")}@${file.originalname}`
        );
      },
    }),
  }).array("file"),
  function (req, res) {
    res.send();
  }
);
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "upload.html"));
});
app.get("/script.js", (req, res) => {
  res.sendFile(path.join(__dirname, "script.js"));
});
app.use((req, res) => {
  res.statusCode = 403;
  res.send();
});
// WebSocket

const receivedDatas: Map<string, Array<Buffer | undefined>> = new Map();

function isArrayOfBuffer(
  datas: Array<Buffer | undefined>
): datas is Array<Buffer> {
  return datas.every((data) => data !== undefined);
}

const ws = new socket_io.Server(h, {
  maxHttpBufferSize: 1e12,
  connectTimeout: 60 * 60 * 1000,
  pingInterval: 1000,
  pingTimeout: 60 * 60 * 1000,
  upgradeTimeout: 60 * 60 * 1000,
});

ws.sockets.on("connection", (socket) => {
  socket.on("message", (data: Data, fn) => {
    fn("");
    const datas =
      receivedDatas.get(data.id) ??
      (() => {
        const arr: Array<Buffer | undefined> = Array(data.dataLength).fill(
          undefined
        );
        receivedDatas.set(data.id, arr);
        return arr;
      })();
    const buffer = (() => {
      const d = Buffer.alloc(data.bodyLength);
      Buffer.from(data.body, "base64").copy(d);
      return d;
    })();
    datas[data.index] = buffer;
    if (isArrayOfBuffer(datas)) {
      // datas is Array<Buffer>
      receivedDatas.delete(data.id);
      let dataLength = 0;
      datas.forEach((data) => (dataLength += data.byteLength));
      const allData = Buffer.alloc(dataLength);

      let nextIndex = 0;
      for (const data of datas) {
        for (const value of data) {
          allData[nextIndex] = value;
          nextIndex++;
        }
      }
      fs.writeFileSync(path.join(__dirname, data.id), allData);
      //console.log(allData.toString())
    }
  });
});

interface Data {
  type: "data";
  dataLength: number;
  index: number;
  id: string;
  // base64 parsed buffer
  body: string;
  bodyLength: number;
}
