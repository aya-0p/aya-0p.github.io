const ws = io.connect();
/**
 * @param {ArrayBuffer} arrayBuffer
 * @returns {string}
 */
function ab2base64(arrayBuffer) {
  let binaryString = "";
  const bytes = new Uint8Array(arrayBuffer);
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binaryString += String.fromCharCode(bytes[i]);
  }
  return btoa(binaryString);
}
async function sendData() {
  const elem = document.getElementById("file");
  if (elem instanceof HTMLInputElement && elem.files) {
    let j = 0;
    for (const file of elem.files) {
      const data = await file.arrayBuffer().catch(() => {
        log(
          "ファイルサイズ上限(2GB)を超えているため送信できませんでした。かわりに「そのまま送信」を利用してください。"
        );
      });
      if (!data) continue;
      const id = `${new Date().toISOString().replace(/:/g, ".")}@${file.name}`;
      /**
       * @type {Array<ArrayBuffer>}
       */
      const buffers = [];
      // 50MiBごとにデータを送信したい
      const splitLength = 1024 * 1024 * 50;
      const split = Math.ceil(data.byteLength / splitLength);
      for (let index = 0; index < split; index++) {
        buffers.push(
          data.slice(index * splitLength, (index + 1) * splitLength)
        );
      }
      let i = 0;
      for (const buffer of buffers) {
        await new Promise((resolve) => {
          ws.emit(
            "message",
            {
              type: "post",
              /**
               * データを送信する回数
               */
              dataLength: split,
              /**
               * データの順番
               */
              index: i,
              /**
               * 日付 + ファイル名
               * ファイル名につけてはいけない文字は使わない(/など)
               */
              id,
              /**
               * データ
               */
              body: ab2base64(buffer),
              /**
               * データの長さ
               */
              bodyLength: buffer.byteLength,
            },
            () => resolve()
          );
        });
        i++;
        log(`Sent ${i}/${split}...`);
      }
      j++;
      log(`File ${j}/${elem.files.length} Done.`);
    }
    log("Done.");
  }
}

async function sendDataWithPost() {
  const elem = document.getElementById("file");
  if (elem instanceof HTMLInputElement && elem.files) {
    let j = 0;
    for (const file of elem.files) {
      await new Promise((resolve) => {
        const formdata = new FormData();
        formdata.append("file", file);
        const ajax = new XMLHttpRequest();
        ajax.upload.addEventListener(
          "progress",
          (event) => {
            const percent = (event.loaded / event.total) * 100;
            logPercent(`Uploading ${percent}%...`);
          },
          false
        );
        ajax.addEventListener(
          "load",
          (event) => {
            log("Upload Complete");
            logPercent("")
            resolve();
          },
          false
        );
        ajax.addEventListener(
          "error",
          (event) => {
            log("Upload Error: error");
            resolve();
          },
          false
        );
        ajax.addEventListener(
          "abort",
          (event) => {
            log("Upload Error: abort");
            resolve();
          },
          false
        );
        ajax.open("POST", "/");
        ajax.send(formdata);
      });
      j++;
      log(`File ${j}/${elem.files.length} Done.`);
    }
    log("Done.");
  }
}

/**
 * @param {string} message
 */
function log(...messages) {
  const elem = document.getElementById("log");
  if (elem)
    messages.forEach(
      (message) =>
        (elem.innerHTML =
          `<br>${message.replace("\n", "<br>")}` + elem.innerHTML)
    );
}

/**
 * @param {string} percent
 */
function logPercent(percent) {
  const elem = document.getElementById("percent");
  if (elem)
    elem.innerHTML = percent
}

/**
 * アップロード結果を表示
 */
(() => {
  /**
   * @type {Map<string, string>}
   */
  const map = new Map();
  for ([k, ...v] of decodeURIComponent(window.location.search)
    .replace(/^\?/, "")
    .split("&")
    .map((t) => t.split("="))) {
    if (k && v) map.set(k, v.join("="));
  }
  const i = map.get("i");
  if (i) {
    const obj = JSON.parse(i);
    if (obj instanceof Array && obj.length) {
      log(...obj.map((str) => `ファイル「${str}」をアップロードしました。`));
    }
  }
})();
